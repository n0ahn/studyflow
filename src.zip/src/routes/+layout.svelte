<script lang="ts">
    import './layout.css'
    import { setAuthContext } from '$lib/stores'
    import { initTheme, toggleTheme } from '$lib/stores/theme'
    import Sidebar from '$lib/components/ui/Sidebar.svelte'
    import type { LayoutData } from './$types'
    import { onMount } from 'svelte'

    let { data, children }: { data: LayoutData, children: any } = $props()

    setAuthContext(() => data.session)

    const isAuthRoute = $derived(data.pathname?.startsWith('/auth'))

    let theme = $state<'dark' | 'light'>('dark')

    onMount(() => {
        theme = initTheme()
    })

    function handleToggle() {
        theme = toggleTheme()
    }
</script>

{#if isAuthRoute}
    {@render children()}
{:else}
    <div class="flex min-h-screen bg-background text-foreground">
        <Sidebar {theme} ontoggle={handleToggle} />
        <main class="flex-1 overflow-y-auto p-8">
            {@render children()}
        </main>
    </div>
{/if}