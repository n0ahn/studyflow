<script lang="ts">
    import type { StudySessionWithDetails } from '$lib/types'
    import DayColumn from './DayColumn.svelte'
    import Button from '$lib/components/ui/Button.svelte'
    import RefreshCw from '@lucide/svelte/icons/refresh-cw'
    import { enhance } from '$app/forms'
    import { invalidateAll } from '$app/navigation'
    import { SvelteDate } from 'svelte/reactivity'

    type Props = {
        sessions: StudySessionWithDetails[]
        from: string
        to: string
    }

    let { sessions, from, to }: Props = $props()

    const today = new SvelteDate().toISOString().split('T')[0]

    let isReplanning = $state(false)
    let summaryMessage = $state<string | null>(null)
    let warnings = $state<string[]>([])

    const days = $derived(() => {
        const result: string[] = []
        const start = new SvelteDate(from)
        const end = new SvelteDate(to)

        const current = new SvelteDate(start)
        while (current <= end) {
            result.push(current.toISOString().split('T')[0])
            current.setDate(current.getDate() + 1)
        }

        return result
    })

    function getSessionsForDay(date: string): StudySessionWithDetails[] {
        return sessions.filter(s => s.date === date)
    }
</script>

<div class="flex flex-col gap-3 mb-4">
    <div class="flex items-center justify-between">
        <div>
            {#if summaryMessage}
                <p class="text-sm text-muted-foreground">{summaryMessage}</p>
            {/if}
        </div>
        <form
            method="POST"
            action="?/replan"
            use:enhance={() => {
                isReplanning = true
                summaryMessage = null
                warnings = []
                return async ({ result }) => {
                    isReplanning = false
                    if (result.type === 'success' && result.data?.compressResult) {
                        const { sessionsCreated, warnings: newWarnings } = result.data.compressResult as {
                            sessionsCreated: number
                            warnings: string[]
                        }
                        warnings = newWarnings
                        summaryMessage = newWarnings.length > 0
                            ? `${sessionsCreated} sessies herverdeeld, maar ${newWarnings.length} item(s) passen nog niet volledig.`
                            : `${sessionsCreated} sessies herverdeeld. Alles past weer binnen de planning.`
                        await invalidateAll()
                    } else {
                        summaryMessage = 'Herplannen is niet gelukt, probeer het opnieuw.'
                    }
                }
            }}
        >
            <Button type="submit" variant="secondary" size="sm" disabled={isReplanning}>
                <RefreshCw size={14} class={isReplanning ? 'animate-spin' : ''} />
                {isReplanning ? 'Herplannen...' : 'Herplan'}
            </Button>
        </form>
    </div>

    {#if warnings.length > 0}
        <div class="border border-amber-500/20 bg-amber-500/5 rounded-xl p-4 flex flex-col gap-1">
            <p class="text-sm font-medium text-amber-400">Niet alles kon ingepland worden</p>
            {#each warnings as warning (warning)}
                <p class="text-xs text-amber-400/60">{warning}</p>
            {/each}
        </div>
    {/if}
</div>

{#if sessions.length === 0}
    <div class="flex flex-col items-center justify-center py-32 gap-3 text-center">
        <div class="w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center">
            <span class="text-2xl">📅</span>
        </div>
        <div>
            <p class="text-sm font-semibold text-foreground">Geen sessies gepland</p>
            <p class="text-sm text-muted-foreground mt-1">Voeg toetsen of taken toe, of klik op Herplan om een planning te genereren.</p>
        </div>
    </div>
{:else}
    <div class="grid gap-4" style="grid-template-columns: repeat({Math.min(days().length, 7)}, minmax(0, 1fr))">
        {#each days().slice(0, 7) as date (date)}
            <DayColumn
                {date}
                sessions={getSessionsForDay(date)}
                isToday={date === today}
            />
        {/each}
    </div>
{/if}