<script lang="ts">
    import type { StudySessionWithDetails } from '$lib/types'

    type Props = {
        session: StudySessionWithDetails
    }

    let { session }: Props = $props()

    const statusConfig = {
        planned:    { class: 'border-border bg-secondary/50', dot: 'bg-muted-foreground' },
        in_progress: { class: 'border-accent/30 bg-accent/5', dot: 'bg-accent' },
        completed:  { class: 'border-emerald-500/30 bg-emerald-500/5', dot: 'bg-emerald-400' },
        missed:     { class: 'border-red-500/30 bg-red-500/5', dot: 'bg-red-400' }
    }

    const config = $derived(() => statusConfig[session.status])

    const duration = $derived(() => {
        const m = session.planned_duration
        if (m < 60) return `${m}m`
        const h = Math.floor(m / 60)
        const rem = m % 60
        return rem === 0 ? `${h}u` : `${h}u${rem}m`
    })
</script>

<div class="border rounded-lg p-2.5 flex flex-col gap-1.5 {config().class}">
    <div class="flex items-center gap-1.5">
        <div
            class="w-1.5 h-1.5 rounded-full shrink-0"
            style="background-color: {session.subject.color}"
        ></div>
        <p class="text-xs font-medium truncate text-foreground">
            {session.exam?.name ?? session.task?.title ?? session.subject.name}
        </p>
    </div>
    <div class="flex items-center justify-between">
        <p class="text-xs text-muted-foreground truncate">{session.subject.name}</p>
        <span class="text-xs text-muted-foreground shrink-0 ml-1">{duration()}</span>
    </div>
</div>