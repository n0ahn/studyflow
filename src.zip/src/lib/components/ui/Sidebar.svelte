<script lang="ts">
    import { page } from '$app/state'
    import { goto } from '$app/navigation'
    import { supabase } from '$lib/supabase'
    import LayoutDashboard from '@lucide/svelte/icons/layout-dashboard'
    import BookOpen from '@lucide/svelte/icons/book-open'
    import ClipboardList from '@lucide/svelte/icons/clipboard-list'
    import CheckSquare from '@lucide/svelte/icons/check-square-2'
    import Calendar from '@lucide/svelte/icons/calendar'
    import Settings from '@lucide/svelte/icons/settings'
    import GraduationCap from '@lucide/svelte/icons/graduation-cap'
    import LogOut from '@lucide/svelte/icons/log-out'
    import Sun from '@lucide/svelte/icons/sun'
    import Moon from '@lucide/svelte/icons/moon'

    type Props = {
        theme: 'dark' | 'light'
        ontoggle: () => void
    }

    let { theme, ontoggle }: Props = $props()

    const links = [
        { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { href: '/subjects',  label: 'Vakken',    icon: BookOpen },
        { href: '/exams',     label: 'Toetsen',   icon: ClipboardList },
        { href: '/tasks',     label: 'Taken',     icon: CheckSquare },
        { href: '/planner',   label: 'Planner',   icon: Calendar },
    ] as const

    const isActive = (href: string) => page.url.pathname === href

    async function handleLogout() {
        await supabase.auth.signOut()
        goto('/auth/login')
    }
</script>

<aside class="w-60 h-screen sticky top-0 flex flex-col bg-sidebar border-r border-sidebar-border">
    <div class="flex items-center gap-2.5 px-5 py-5 border-b border-sidebar-border">
        <div class="w-7 h-7 rounded-lg bg-accent flex items-center justify-center shrink-0">
            <GraduationCap size={15} class="text-white" />
        </div>
        <span class="font-semibold text-sm tracking-tight text-foreground">StudyFlow</span>
    </div>

    <nav class="flex-1 flex flex-col gap-0.5 p-3 overflow-y-auto">
        {#each links as link}
            <a
                href={link.href}
                class="flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150
                    {isActive(link.href)
                        ? 'bg-accent/15 text-accent font-medium'
                        : 'text-muted-foreground hover:text-foreground hover:bg-accent/5'}"
            >
                <link.icon size={16} class="shrink-0" />
                <span>{link.label}</span>
                {#if isActive(link.href)}
                    <div class="ml-auto w-1 h-1 rounded-full bg-accent"></div>
                {/if}
            </a>
        {/each}
    </nav>

    <div class="p-3 border-t border-sidebar-border flex flex-col gap-0.5">
        <a
            href="/settings"
            class="flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150
                {isActive('/settings')
                    ? 'bg-accent/15 text-accent font-medium'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent/5'}"
        >
            <Settings size={16} class="shrink-0" />
            <span>Instellingen</span>
        </a>

        <button
            onclick={ontoggle}
            class="flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150
                text-muted-foreground hover:text-foreground hover:bg-accent/5 w-full text-left"
        >
            {#if theme === 'dark'}
                <Sun size={16} class="shrink-0" />
                <span>Light mode</span>
            {:else}
                <Moon size={16} class="shrink-0" />
                <span>Dark mode</span>
            {/if}
        </button>

        <button
            onclick={handleLogout}
            class="flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150
                text-muted-foreground hover:text-destructive hover:bg-destructive/10 w-full text-left"
        >
            <LogOut size={16} class="shrink-0" />
            <span>Uitloggen</span>
        </button>
    </div>
</aside>